import React, { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import {
  Paper,
  Typography,
  CircularProgress,
  Box,
} from '@mui/material';
import { fetchWeather } from '../store/slices/todoSlice';

function WeatherWidget() {
  const dispatch = useDispatch();
  const { weather, status, error } = useSelector((state) => state.todos);
  const [city] = useState('London'); // Default city, you can make this dynamic

  useEffect(() => {
    dispatch(fetchWeather(city));
  }, [dispatch, city]);

  if (status === 'loading') {
    return <CircularProgress />;
  }

  if (status === 'failed') {
    return <Typography color="error">{error}</Typography>;
  }

  if (!weather) {
    return null;
  }

  return (
    <Paper elevation={1} sx={{ p: 2, mb: 3, bgcolor: 'primary.light' }}>
      <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <Typography variant="h6" color="white">
          Weather in {weather.name}
        </Typography>
        <Typography variant="h6" color="white">
          {Math.round(weather.main.temp)}°C
        </Typography>
      </Box>
      <Typography variant="body2" color="white">
        {weather.weather[0].description}
      </Typography>
    </Paper>
  );
}

export default WeatherWidget;