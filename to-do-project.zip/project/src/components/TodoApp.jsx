import React, { useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import {
  Container,
  Paper,
  Box,
  Typography,
  Button,
} from '@mui/material';
import { logout } from '../store/slices/authSlice';
import TaskInput from './TaskInput';
import TaskList from './TaskList';
import WeatherWidget from './WeatherWidget';

function TodoApp() {
  const dispatch = useDispatch();
  const user = useSelector((state) => state.auth.user);

  const handleLogout = () => {
    dispatch(logout());
  };

  return (
    <Container maxWidth="md">
      <Box sx={{ mt: 4, mb: 4 }}>
        <Paper elevation={3} sx={{ p: 3 }}>
          <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 3 }}>
            <Typography variant="h4" component="h1">
              Welcome, {user?.username}!
            </Typography>
            <Button variant="outlined" color="secondary" onClick={handleLogout}>
              Logout
            </Button>
          </Box>
          <WeatherWidget />
          <TaskInput />
          <TaskList />
        </Paper>
      </Box>
    </Container>
  );
}

export default TodoApp;