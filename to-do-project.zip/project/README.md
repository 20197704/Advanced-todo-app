# Advanced Todo Application

A feature-rich Todo application built with React, Redux, and Material-UI, featuring weather integration and user authentication.

## Features

- **User Authentication**
  - Login/logout functionality
  - Protected routes
  - Persistent authentication state

- **Todo Management**
  - Add tasks with priority levels (High, Medium, Low)
  - Delete tasks
  - Visual priority indicators
  - Persistent storage

- **Weather Integration**
  - Real-time weather display
  - City-specific weather data
  - Error handling for API requests

- **Responsive Design**
  - Mobile-first approach
  - Adaptive layout for all screen sizes
  - Material Design components

## Technology Stack

- React 18
- Redux Toolkit
- Material-UI
- React Router
- OpenWeatherMap API
- Vite

## Setup Instructions

1. Clone the repository
2. Install dependencies:
   ```bash
   npm install
   ```
3. Create a `.env` file and add your OpenWeatherMap API key:
   ```
   VITE_WEATHER_API_KEY=your_api_key_here
   ```
4. Start the development server:
   ```bash
   npm run dev
   ```

## Usage

1. **Authentication**
   - Use any username/password combination to log in
   - Authentication state persists across page reloads

2. **Managing Tasks**
   - Add new tasks using the input field
   - Set priority levels for tasks
   - Delete tasks using the delete icon
   - Tasks are automatically saved to localStorage

3. **Weather Widget**
   - Displays current weather for the default city
   - Shows temperature and weather conditions
   - Updates automatically

## Project Structure

```
src/
├── components/         # React components
├── store/             # Redux store and slices
├── theme.js           # Material-UI theme configuration
└── App.jsx            # Main application component
```

## Deployment

The application is deployed and can be accessed at: [Live Demo URL]